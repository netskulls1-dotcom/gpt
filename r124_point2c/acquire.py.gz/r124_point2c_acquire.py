#!/usr/bin/env python3
"""R124 Point-2C: official Binance monthly archive preflight and acquisition.

Strategy-blind transport layer for the versioned R124 historical-coverage-qualified Top-50 basket.
Thomas/LC-2B is not referenced or executed.  The script first classifies all
1,200 official monthly kline units.  It downloads and normalizes the full set
only when every official checksum/archive is available.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import math
import os
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
import re
import shutil
import tempfile
import time
from typing import Any, Iterable
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen
from zipfile import BadZipFile, ZipFile

RELEASE = "V20979 R124"
SCHEMA = "photon.r124.point2c.v1"
ROOT_URL = "https://data.binance.vision/data/futures/um/monthly/klines"
SYMBOLS = [
    "BTCUSDT",
    "ETHUSDT",
    "XRPUSDT",
    "SOLUSDT",
    "HYPEUSDT",
    "ZECUSDT",
    "ENAUSDT",
    "ONGUSDT",
    "DOGEUSDT",
    "BNBUSDT",
    "1000PEPEUSDT",
    "SUIUSDT",
    "BCHUSDT",
    "LINKUSDT",
    "ADAUSDT",
    "PUMPUSDT",
    "BOMEUSDT",
    "HEMIUSDT",
    "WLDUSDT",
    "NEARUSDT",
    "ASTERUSDT",
    "TRUMPUSDT",
    "ACEUSDT",
    "AVAXUSDT",
    "AAVEUSDT",
    "BEATUSDT",
    "NEIROUSDT",
    "TAOUSDT",
    "PEOPLEUSDT",
    "ONDOUSDT",
    "UNIUSDT",
    "LTCUSDT",
    "PAXGUSDT",
    "PENGUUSDT",
    "LITUSDT",
    "CRVUSDT",
    "TUTUSDT",
    "FILUSDT",
    "XLMUSDT",
    "AVAAIUSDT",
    "BBUSDT",
    "1000SHIBUSDT",
    "XPLUSDT",
    "GALAUSDT",
    "ONTUSDT",
    "FARTCOINUSDT",
    "FETUSDT",
    "WLFIUSDT",
    "DOTUSDT",
    "HBARUSDT",
]
INTERVALS = ["1d", "4h", "1h", "15m", "5m", "1m"]
MONTHS = ["2026-04", "2026-05", "2026-06", "2026-07"]
EXCLUDED_FOR_INSUFFICIENT_HISTORY = ["BTWUSDT", "REUSDT"]
COVERAGE_REPLACEMENTS = ["DOTUSDT", "HBARUSDT"]
INTERVAL_MS = {
    "1m": 60_000,
    "5m": 300_000,
    "15m": 900_000,
    "1h": 3_600_000,
    "4h": 14_400_000,
    "1d": 86_400_000,
}
HEADER = [
    "open_time", "close_time", "open", "high", "low", "close", "volume",
    "quote_asset_volume", "number_of_trades", "taker_buy_base_volume",
    "taker_buy_quote_volume", "ignore",
]
HEX64 = re.compile(r"\b([0-9a-fA-F]{64})\b")


@dataclass(frozen=True)
class Unit:
    index: int
    symbol: str
    interval: str
    month: str
    unit_id: str
    url: str
    checksum_url: str


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


def units() -> list[Unit]:
    out: list[Unit] = []
    idx = 0
    for symbol in SYMBOLS:
        for interval in INTERVALS:
            for month in MONTHS:
                idx += 1
                name = f"{symbol}-{interval}-{month}.zip"
                url = f"{ROOT_URL}/{symbol}/{interval}/{name}"
                out.append(Unit(idx, symbol, interval, month, f"kline:{symbol}:{interval}:{month}", url, url + ".CHECKSUM"))
    assert len(out) == 1200
    return out


def canonical_sha(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()).hexdigest()


def read_checksum(text: str) -> str:
    match = HEX64.search(text)
    if not match:
        raise ValueError("checksum response contains no SHA-256")
    return match.group(1).lower()


def request_bytes(url: str, *, timeout: int, method: str = "GET", headers: dict[str, str] | None = None) -> tuple[bytes, int, dict[str, str]]:
    h = {"User-Agent": "Photon-R124/1.0"}
    if headers:
        h.update(headers)
    request = Request(url, headers=h, method=method)
    with urlopen(request, timeout=timeout) as response:  # noqa: S310 - frozen official Binance URL
        status = int(getattr(response, "status", response.getcode()))
        body = response.read()
        return body, status, dict(response.headers.items())


def probe_archive(url: str, *, timeout: int) -> tuple[str, int | None, str | None]:
    try:
        _, status, _ = request_bytes(url, timeout=timeout, method="HEAD")
        return "PRESENT", status, None
    except HTTPError as exc:
        if exc.code == 405:
            try:
                _, status, _ = request_bytes(url, timeout=timeout, headers={"Range": "bytes=0-0"})
                return "PRESENT", status, None
            except HTTPError as inner:
                return ("MISSING_404", inner.code, str(inner)) if inner.code == 404 else ("HTTP_ERROR", inner.code, str(inner))
        return ("MISSING_404", exc.code, str(exc)) if exc.code == 404 else ("HTTP_ERROR", exc.code, str(exc))
    except (URLError, OSError) as exc:
        return "NETWORK_ERROR", None, f"{type(exc).__name__}: {exc}"


def preflight_one(unit: Unit, *, retries: int, timeout: int) -> dict[str, Any]:
    last_error: str | None = None
    for attempt in range(1, retries + 1):
        try:
            body, status, _ = request_bytes(unit.checksum_url, timeout=timeout)
            expected = read_checksum(body.decode("utf-8", errors="replace"))
            return {
                **asdict(unit),
                "status": "AVAILABLE",
                "checksum_http_status": status,
                "archive_http_status": None,
                "published_sha256": expected,
                "attempt": attempt,
                "error": None,
                "checked_at_utc": now(),
            }
        except HTTPError as exc:
            if exc.code == 404:
                archive_state, archive_status, archive_error = probe_archive(unit.url, timeout=timeout)
                if archive_state == "MISSING_404":
                    return {
                        **asdict(unit),
                        "status": "UNAVAILABLE_OFFICIAL_404",
                        "checksum_http_status": 404,
                        "archive_http_status": archive_status,
                        "published_sha256": None,
                        "attempt": attempt,
                        "error": archive_error,
                        "checked_at_utc": now(),
                    }
                if archive_state == "PRESENT":
                    return {
                        **asdict(unit),
                        "status": "CHECKSUM_MISSING_ARCHIVE_PRESENT_FAIL_CLOSED",
                        "checksum_http_status": 404,
                        "archive_http_status": archive_status,
                        "published_sha256": None,
                        "attempt": attempt,
                        "error": "archive exists but published checksum is missing",
                        "checked_at_utc": now(),
                    }
                last_error = archive_error
            else:
                last_error = f"HTTPError {exc.code}: {exc}"
        except (URLError, OSError, ValueError) as exc:
            last_error = f"{type(exc).__name__}: {exc}"
        if attempt < retries:
            time.sleep(min(2 ** (attempt - 1), 8))
    return {
        **asdict(unit),
        "status": "PROBE_FAILED_RETRYABLE",
        "checksum_http_status": None,
        "archive_http_status": None,
        "published_sha256": None,
        "attempt": retries,
        "error": last_error,
        "checked_at_utc": now(),
    }


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    tmp.replace(path)


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = list(rows[0].keys()) if rows else []
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    tmp.replace(path)


def summarise(rows: list[dict[str, Any]]) -> dict[str, Any]:
    counts: dict[str, int] = {}
    by_symbol: dict[str, dict[str, int]] = {}
    by_interval: dict[str, dict[str, int]] = {}
    by_month: dict[str, dict[str, int]] = {}
    for row in rows:
        status = row["status"]
        counts[status] = counts.get(status, 0) + 1
        for bucket, key in ((by_symbol, row["symbol"]), (by_interval, row["interval"]), (by_month, row["month"])):
            inner = bucket.setdefault(key, {})
            inner[status] = inner.get(status, 0) + 1
    unavailable = [row for row in rows if row["status"] != "AVAILABLE"]
    available = counts.get("AVAILABLE", 0)
    return {
        "schema": SCHEMA + ".preflight_summary",
        "release": RELEASE,
        "created_at_utc": now(),
        "frozen_basket_sha256": canonical_sha(SYMBOLS),
        "symbol_count": len(SYMBOLS),
        "intervals": INTERVALS,
        "months": MONTHS,
        "unit_count": len(rows),
        "status_counts": dict(sorted(counts.items())),
        "available_units": available,
        "unavailable_or_failed_units": len(rows) - available,
        "all_1200_official_units_available": available == 1200,
        "point2c_full_acquisition_allowed": available == 1200,
        "point2c_status": "PREFLIGHT_PASS_ALL_AVAILABLE" if available == 1200 else "PREFLIGHT_FAIL_CLOSED_MISSING_OR_FAILED",
        "accuracy_allowed": False,
        "accuracy_block_reason": "POINT2C_DOWNLOAD_NORMALIZE_POINT3_AUDIT_REQUIRED" if available == 1200 else "FROZEN_TOP50_HAS_UNAVAILABLE_OR_UNVERIFIED_OFFICIAL_UNITS",
        "partial_basket_accuracy_allowed": False,
        "silent_symbol_substitution": False,
        "basket_policy": "VERSIONED_HISTORICAL_COVERAGE_QUALIFIED_TOP50",
        "excluded_for_insufficient_history": EXCLUDED_FOR_INSUFFICIENT_HISTORY,
        "coverage_replacements_in_source_rank_order": COVERAGE_REPLACEMENTS,
        "thomas_executed": False,
        "strategy_core_mutated": False,
        "by_symbol": by_symbol,
        "by_interval": by_interval,
        "by_month": by_month,
        "first_100_unavailable_or_failed": unavailable[:100],
    }


def write_summary_md(path: Path, summary: dict[str, Any]) -> None:
    lines = [
        "# R124 Point 2C — Official Archive Preflight",
        "",
        f"- Release: **{summary['release']}**",
        f"- Units: **{summary['available_units']}/{summary['unit_count']} available**",
        f"- Point 2C status: **{summary['point2c_status']}**",
        f"- Full acquisition allowed: **{summary['point2c_full_acquisition_allowed']}**",
        "- Thomas/LC-2B executed: **NO**",
        "- Strategy core changed: **NO**",
        "- Partial-basket accuracy: **BLOCKED**",
        "",
        "## Status counts",
        "",
    ]
    for key, value in summary["status_counts"].items():
        lines.append(f"- `{key}`: **{value}**")
    bad_symbols = []
    for symbol, counts in summary["by_symbol"].items():
        bad = sum(v for k, v in counts.items() if k != "AVAILABLE")
        if bad:
            bad_symbols.append((symbol, bad, counts))
    lines += ["", "## Symbols with unavailable/failed units", ""]
    if not bad_symbols:
        lines.append("- None")
    else:
        for symbol, bad, counts in bad_symbols:
            lines.append(f"- `{symbol}`: **{bad}** non-available — `{json.dumps(counts, sort_keys=True)}`")
    lines += [
        "",
        "## Locked consequence",
        "",
        "R121 remains preserved. R124 is a new, explicitly versioned coverage-qualified basket: BTWUSDT and REUSDT are excluded because April-May warm-up archives are unavailable; DOTUSDT and HBARUSDT are the next source-ranked candidates with 24/24 archive coverage.",
        "",
    ]
    path.write_text("\n".join(lines), encoding="utf-8")


def cmd_preflight(args: argparse.Namespace) -> int:
    out = Path(args.output)
    out.mkdir(parents=True, exist_ok=True)
    all_units = units()
    rows: list[dict[str, Any]] = []
    with ThreadPoolExecutor(max_workers=args.workers, thread_name_prefix="r124-probe") as executor:
        futures = {executor.submit(preflight_one, unit, retries=args.retries, timeout=args.timeout): unit for unit in all_units}
        for idx, future in enumerate(as_completed(futures), start=1):
            rows.append(future.result())
            if idx % 50 == 0:
                print(f"preflight {idx}/1200", flush=True)
    rows.sort(key=lambda row: row["index"])
    summary = summarise(rows)
    write_json(out / "R124_POINT2C_PREFLIGHT_LEDGER.json", rows)
    write_csv(out / "R124_POINT2C_PREFLIGHT_LEDGER.csv", rows)
    write_json(out / "R124_POINT2C_PREFLIGHT_SUMMARY.json", summary)
    write_summary_md(out / "R124_POINT2C_PREFLIGHT_SUMMARY.md", summary)
    print(json.dumps(summary, indent=2))
    return 0


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def download_to(url: str, path: Path, *, timeout: int) -> int:
    path.parent.mkdir(parents=True, exist_ok=True)
    part = path.with_suffix(path.suffix + ".part")
    headers: dict[str, str] = {}
    offset = part.stat().st_size if part.exists() else 0
    if offset:
        headers["Range"] = f"bytes={offset}-"
    request = Request(url, headers={"User-Agent": "Photon-R124/1.0", **headers})
    with urlopen(request, timeout=timeout) as response:  # noqa: S310
        status = int(getattr(response, "status", response.getcode()))
        if offset and status != 206:
            part.unlink(missing_ok=True)
            return download_to(url, path, timeout=timeout)
        mode = "ab" if offset else "wb"
        with part.open(mode) as handle:
            shutil.copyfileobj(response, handle, length=1024 * 1024)
    part.replace(path)
    return path.stat().st_size


def timestamp_ms(value: str) -> int:
    raw = int(value)
    while raw >= 100_000_000_000_000:  # micro/nanosecond archives -> milliseconds
        raw //= 1000
    return raw


def month_bounds(month: str) -> tuple[int, int]:
    start = datetime.strptime(month + "-01", "%Y-%m-%d").replace(tzinfo=timezone.utc)
    year = start.year + (1 if start.month == 12 else 0)
    next_month = 1 if start.month == 12 else start.month + 1
    end = datetime(year, next_month, 1, tzinfo=timezone.utc)
    return int(start.timestamp() * 1000), int(end.timestamp() * 1000)


def normalize_archive(unit: Unit, archive: Path, normalized: Path) -> dict[str, Any]:
    expected_member = archive.name.removesuffix(".zip") + ".csv"
    with ZipFile(archive) as zf:
        members = [name for name in zf.namelist() if not name.endswith("/")]
        if members != [expected_member]:
            raise ValueError(f"unexpected members {members}, expected {[expected_member]}")
        bad = zf.testzip()
        if bad:
            raise BadZipFile(f"CRC failed: {bad}")
        raw_text = zf.read(expected_member).decode("utf-8-sig", errors="strict")
    reader = csv.reader(io.StringIO(raw_text))
    normalized.parent.mkdir(parents=True, exist_ok=True)
    tmp = normalized.with_suffix(".csv.tmp")
    month_start, month_end = month_bounds(unit.month)
    step = INTERVAL_MS[unit.interval]
    rows = 0
    gaps = 0
    previous: int | None = None
    first_open: int | None = None
    last_open: int | None = None
    with tmp.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(HEADER)
        for raw in reader:
            if not raw:
                continue
            try:
                open_time = timestamp_ms(raw[0])
            except (ValueError, IndexError):
                if rows == 0:  # futures archive header
                    continue
                raise
            if len(raw) < 12:
                raise ValueError(f"row has {len(raw)} columns")
            close_time = timestamp_ms(raw[6])
            o, h, l, c, volume = map(float, raw[1:6])
            if not all(math.isfinite(x) for x in (o, h, l, c, volume)):
                raise ValueError("non-finite OHLCV")
            if h < max(o, c, l) or l > min(o, c, h) or volume < 0:
                raise ValueError("invalid OHLCV geometry")
            if not (month_start <= open_time < month_end):
                raise ValueError(f"open time outside month: {open_time}")
            if previous is not None:
                delta = open_time - previous
                if delta <= 0:
                    raise ValueError("duplicate/backward candle")
                if delta > step:
                    gaps += max(1, delta // step - 1)
            writer.writerow([
                open_time, close_time, raw[1], raw[2], raw[3], raw[4], raw[5],
                raw[7], raw[8], raw[9], raw[10], raw[11],
            ])
            first_open = open_time if first_open is None else first_open
            last_open = open_time
            previous = open_time
            rows += 1
    if rows == 0:
        tmp.unlink(missing_ok=True)
        raise ValueError("zero normalized rows")
    tmp.replace(normalized)
    return {
        "normalized_rows": rows,
        "normalized_sha256": sha256_file(normalized),
        "first_open_time_ms": first_open,
        "last_open_time_ms": last_open,
        "gaps_observed_for_point3": gaps,
    }


def acquire_one(row: dict[str, Any], *, output: Path, timeout: int, retries: int, keep_raw: bool) -> dict[str, Any]:
    unit = Unit(row["index"], row["symbol"], row["interval"], row["month"], row["unit_id"], row["url"], row["checksum_url"])
    raw_path = output / "raw" / unit.symbol / unit.interval / Path(unit.url).name
    normalized = output / "normalized" / unit.symbol / unit.interval / f"{unit.month}.csv"
    expected = row["published_sha256"]
    last_error: str | None = None
    for attempt in range(1, retries + 1):
        try:
            if not raw_path.is_file() or sha256_file(raw_path) != expected:
                download_to(unit.url, raw_path, timeout=timeout)
            actual = sha256_file(raw_path)
            if actual != expected:
                raw_path.unlink(missing_ok=True)
                raise ValueError(f"SHA mismatch {actual} != {expected}")
            info = normalize_archive(unit, raw_path, normalized)
            archive_bytes = raw_path.stat().st_size
            if not keep_raw:
                raw_path.unlink(missing_ok=True)
            return {
                **row,
                "status": "NORMALIZED",
                "attempt": attempt,
                "archive_sha256": actual,
                "archive_bytes": archive_bytes,
                "normalized_path": normalized.relative_to(output).as_posix(),
                **info,
                "error": None,
                "finished_at_utc": now(),
            }
        except (HTTPError, URLError, OSError, ValueError, BadZipFile, UnicodeError) as exc:
            last_error = f"{type(exc).__name__}: {exc}"
            if attempt < retries:
                time.sleep(min(2 ** (attempt - 1), 8))
    return {
        **row,
        "status": "ACQUIRE_OR_NORMALIZE_FAILED",
        "attempt": retries,
        "error": last_error,
        "finished_at_utc": now(),
    }


def cmd_acquire(args: argparse.Namespace) -> int:
    source = Path(args.preflight) / "R124_POINT2C_PREFLIGHT_LEDGER.json"
    rows = json.loads(source.read_text(encoding="utf-8"))
    if len(rows) != 1200 or any(row["status"] != "AVAILABLE" for row in rows):
        raise SystemExit("fail closed: acquisition requires 1,200 AVAILABLE preflight units")
    out = Path(args.output)
    out.mkdir(parents=True, exist_ok=True)
    results: list[dict[str, Any]] = []
    with ThreadPoolExecutor(max_workers=args.workers, thread_name_prefix="r124-acquire") as executor:
        futures = {
            executor.submit(acquire_one, row, output=out, timeout=args.timeout, retries=args.retries, keep_raw=args.keep_raw): row
            for row in rows
        }
        for idx, future in enumerate(as_completed(futures), start=1):
            results.append(future.result())
            if idx % 25 == 0:
                print(f"acquire {idx}/1200", flush=True)
    results.sort(key=lambda row: row["index"])
    write_json(out / "R124_POINT2C_ACQUISITION_LEDGER.json", results)
    write_csv(out / "R124_POINT2C_ACQUISITION_LEDGER.csv", results)
    counts: dict[str, int] = {}
    for row in results:
        counts[row["status"]] = counts.get(row["status"], 0) + 1
    normalized = counts.get("NORMALIZED", 0)
    summary = {
        "schema": SCHEMA + ".acquisition_summary",
        "release": RELEASE,
        "created_at_utc": now(),
        "unit_count": 1200,
        "status_counts": counts,
        "normalized_units": normalized,
        "all_1200_normalized": normalized == 1200,
        "point2c_status": "DONE_PASS_ALL_1200_NORMALIZED" if normalized == 1200 else "FAIL_CLOSED_INCOMPLETE",
        "point3_audit_allowed": normalized == 1200,
        "accuracy_allowed": False,
        "basket_policy": "VERSIONED_HISTORICAL_COVERAGE_QUALIFIED_TOP50",
        "excluded_for_insufficient_history": EXCLUDED_FOR_INSUFFICIENT_HISTORY,
        "coverage_replacements_in_source_rank_order": COVERAGE_REPLACEMENTS,
        "thomas_executed": False,
        "strategy_core_mutated": False,
    }
    write_json(out / "R124_POINT2C_ACQUISITION_SUMMARY.json", summary)
    print(json.dumps(summary, indent=2))
    return 0 if normalized == 1200 else 2


def cmd_self_test() -> int:
    assert len(SYMBOLS) == 50 and len(set(SYMBOLS)) == 50
    assert len(units()) == 1200
    assert read_checksum("abc " + "a" * 64 + " file.zip") == "a" * 64
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        unit = Unit(1, "BTCUSDT", "1h", "2026-04", "x", "", "")
        member = "BTCUSDT-1h-2026-04.csv"
        archive = root / "BTCUSDT-1h-2026-04.zip"
        rows = [
            ["open_time", "open", "high", "low", "close", "volume", "close_time", "quote", "trades", "tb", "tq", "ignore"],
            ["1775001600000", "1", "2", "0.5", "1.5", "10", "1775005199999", "15", "3", "4", "6", "0"],
            ["1775005200000", "1.5", "2.2", "1", "2", "11", "1775008799999", "20", "4", "5", "8", "0"],
        ]
        with ZipFile(archive, "w") as zf:
            buf = io.StringIO(); csv.writer(buf).writerows(rows); zf.writestr(member, buf.getvalue())
        normalized = root / "2026-04.csv"
        info = normalize_archive(unit, archive, normalized)
        assert info["normalized_rows"] == 2
    print(json.dumps({"release": RELEASE, "pass": True, "tests": 5}, indent=2))
    return 0


def main() -> int:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    p = sub.add_parser("preflight")
    p.add_argument("--output", required=True)
    p.add_argument("--workers", type=int, default=32)
    p.add_argument("--retries", type=int, default=4)
    p.add_argument("--timeout", type=int, default=30)
    p = sub.add_parser("acquire")
    p.add_argument("--preflight", required=True)
    p.add_argument("--output", required=True)
    p.add_argument("--workers", type=int, default=16)
    p.add_argument("--retries", type=int, default=4)
    p.add_argument("--timeout", type=int, default=90)
    p.add_argument("--keep-raw", action="store_true")
    sub.add_parser("self-test")
    args = parser.parse_args()
    if args.command == "preflight":
        return cmd_preflight(args)
    if args.command == "acquire":
        return cmd_acquire(args)
    return cmd_self_test()


if __name__ == "__main__":
    raise SystemExit(main())
